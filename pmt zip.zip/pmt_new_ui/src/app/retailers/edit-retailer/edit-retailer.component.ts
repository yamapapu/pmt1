import { Component, OnInit } from '@angular/core';
// import { RetailersService } from '../../shared/retailers.service';
// import { NotificationService } from '../../shared/notification.service';
// import { CountryService } from '../../shared/country-dropdown.service';
// import { StateDropdownService } from 'src/app/shared/state-dropdown.service';
// import { CityDropdownService } from 'src/app/shared/city-dropdown.service';
// import { Router } from '@angular/router';
@Component({
  selector: 'app-edit-retailer',
  templateUrl: './edit-retailer.component.html',
  styleUrls: ['./edit-retailer.component.css']
})
export class EditRetailerComponent implements OnInit {

  // constructor(private service: RetailersService,
  //   private notificationService: NotificationService,
  //   private countryService: CountryService,
  //   private stateService: StateDropdownService,
  //   private cityService: CityDropdownService,
  //   private router: Router) { }

  //   ngOnInit() {
  //     this.service.getRetailers();
     
  //   }

  //   onClear() {
  //     this.service.form.reset();
  //     this.service.initializeFormGroup();
  //   }
  //   onUpdate() {
  //     if (this.service.form.valid) {

  //       this.service.updateRetailer(this.service.form.value);
  //       this.service.form.reset();
  //       this.service.initializeFormGroup();
  //       this.notificationService.success(':: Updated successfully');
  //       this.router.navigate(['list-cmp']);
  //     }
  //   }
  constructor(){}
  ngOnInit(){}

}
