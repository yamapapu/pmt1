export interface Category1 {
  
id: number;
Category_name: string;
}