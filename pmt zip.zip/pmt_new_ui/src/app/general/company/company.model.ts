export class Company1 {
  
    Category_id: number;    
    Company_id: number;
    Company_name: string;
      static id: any;
    }