import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-itemsadd',
  templateUrl: './itemsadd.component.html',
  styleUrls: ['./itemsadd.component.css']
})
export class ItemsaddComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
