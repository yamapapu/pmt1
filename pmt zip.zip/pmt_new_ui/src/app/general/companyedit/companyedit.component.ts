import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-companyedit',
  templateUrl: './companyedit.component.html',
  styleUrls: ['./companyedit.component.css']
})
export class CompanyeditComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
