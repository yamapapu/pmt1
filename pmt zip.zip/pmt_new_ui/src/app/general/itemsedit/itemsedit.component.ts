import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-itemsedit',
  templateUrl: './itemsedit.component.html',
  styleUrls: ['./itemsedit.component.css']
})
export class ItemseditComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
